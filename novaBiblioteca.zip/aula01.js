var utils = new Utils();
utils.initBuffer();
utils.initShader();
utils.linkBuffer();
utils.drawElements();
